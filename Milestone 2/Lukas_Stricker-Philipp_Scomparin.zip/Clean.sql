/*
*   Group Members:  Lukas Stricker 14433, lsustricker@unibz.it 
*                   Philipp Scomparin 14109, Philipp.Scomparin@stud-inf.unibz.it
*/ 

drop table Vehicles_Equipment;
drop table Reservations_ExtraEquipment;
drop table Reservations_Damages;
drop table Reservations;
drop table Equipment;
drop table Extra_Equipment;
drop table Bills;
drop table Clients;
drop table Addresses;
drop table Vehicles;
drop table Insurances;
drop table Car_Brands;
drop table Damages;